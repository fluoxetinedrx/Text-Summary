const express = require('express');
const multer = require('multer');
const fs = require('fs');
const mammoth = require('mammoth');

const app = express();
const upload = multer({ dest: 'uploads/' });

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/upload.html');
});

app.post('/upload', upload.single('file'), async (req, res) => {
    try {
        const file = req.file;
        if (!file) {
            return res.send('No selected file');
        }

        const filename = file.path;
        const text = await extractTextFromWord(filename);
        fs.unlinkSync(filename);

        // Format the text if necessary
        // For example:
        // const formattedText = formatText(text);

        // Convert line breaks to HTML line breaks
        const htmlText = text.replace(/\n/g, '<br>');

        res.send(htmlText);
    } catch (error) {
        console.error(error);
        res.status(500).send('Error processing file');
    }
});

async function extractTextFromWord(wordPath) {
    const { value } = await mammoth.extractRawText({ path: wordPath });
    return value;
}

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
