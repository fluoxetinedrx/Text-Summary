const express = require('express');
const multer = require('multer');
const fs = require('fs');
const pdfParse = require('pdf-parse');

const app = express();
const upload = multer({ dest: 'uploads/' });

async function extractSummaryFromPdf(pdfPath) {
    const pdfBuffer = fs.readFileSync(pdfPath);
    const data = await pdfParse(pdfBuffer);
    const text = data.text;

    // Split the text into paragraphs
    const paragraphs = text.split('\n\n');

    // Take the first few paragraphs as the summary
    let summary = paragraphs.slice(0, 3).join('\n\n');

    // Format the summary
    summary = formatSummary(summary);
    return summary;
}

function formatSummary(summary) {
    // Thêm dấu cách sau mỗi dấu chấm câu
    summary = summary.replace(/(\.)([^\s])/g, "$1 $2");

    // Thêm dấu cách sau mỗi dấu chấm hỏi và dấu chấm than
    summary = summary.replace(/(\?|!)([^\s])/g, "$1 $2");

    // Thêm dấu cách trước và sau dấu phẩy, dấu chấm phẩy, dấu hai chấm
    summary = summary.replace(/(\,|;|:)/g, " $1 ");

    // Xóa các dấu cách dư thừa
    summary = summary.replace(/\s+/g, " ");

    return summary;
}

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/upload.html');
});

app.post('/upload', upload.single('file'), async (req, res) => {
    try {
        const file = req.file;
        if (!file) {
            return res.send('No selected file');
        }

        const filename = file.path;
        const summary = await extractSummaryFromPdf(filename);
        fs.unlinkSync(filename);

        // Convert line breaks to HTML line breaks
        const htmlSummary = summary.replace(/\n/g, '<br>');

        res.send(htmlSummary);
    } catch (error) {
        console.error(error);
        res.status(500).send('Error processing file');
    }
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
