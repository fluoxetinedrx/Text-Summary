const express = require('express'); // Import thư viện Express.js
const multer  = require('multer'); // Import thư viện multer để xử lý việc tải lên tệp
const fs = require('fs'); // Import thư viện fs để đọc và ghi tệp
const { PDFDocument } = require('pdf-lib'); // Import thư viện pdf-lib để xử lý tệp PDF

const app = express(); // Khởi tạo ứng dụng Express
const upload = multer({ dest: 'uploads/' }); // Cấu hình middleware multer để lưu tệp tải lên vào thư mục 'uploads/'

// Định tuyến GET cho trang chính
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/upload.html');
});

// Định tuyến POST cho việc tải lên tệp PDF
app.post('/upload', upload.single('file'), async (req, res) => {
    try {
        const file = req.file; // Lấy thông tin về tệp tải lên
        if (!file) {
            return res.send('No selected file');
        }

        const filename = file.path; // Lấy đường dẫn tệp tải lên
        const text = await extractTextFromPdf(filename); // Trích xuất văn bản từ tệp PDF
        fs.unlinkSync(filename); // Xóa tệp tải lên sau khi đã xử lý

        res.send(text); // Trả về văn bản đã trích xuất cho người dùng
    } catch (error) {
        console.error(error);
        res.status(500).send('Error processing file'); // Trả về lỗi nếu có lỗi xảy ra trong quá trình xử lý
    }
});

// Hàm bất đồng bộ để trích xuất văn bản từ tệp PDF
async function extractTextFromPdf(pdfPath) {
    const pdfBytes = fs.readFileSync(pdfPath);
    const pdfDoc = await PDFDocument.load(pdfBytes);
    const pages = pdfDoc.getPages();
    let text = '';
    for (const page of pages) {
        const content = await page.getText();
        text += content + '\n';
    }
    return text;
}

// Lắng nghe các yêu cầu trên cổng 3000 và in ra console khi server đã chạy
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
